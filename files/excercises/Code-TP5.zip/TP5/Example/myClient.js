


function retrieveArtist() {

    var artistID = document.getElementById("artistToRetrieve").value;
    var operationURL = "/artist/" + artistID;

    if(artistID !== "") {

        DZ.api(operationURL, function(response){
            var artistName = response.name;
            var artistPicture = response.picture;

            img = document.createElement("img");
            img.src = artistPicture;

            document.getElementById("image").innerHTML = "";
            document.getElementById("image").appendChild(img);

            var nameElement = document.createElement("p");
            nameElement.innerHTML = artistName;

            document.getElementById("name").innerHTML = "";
            document.getElementById("name").appendChild(nameElement);

        });
    }
}

function retrieveTop5() {

    var artistID = document.getElementById("artistToRetrieve").value;
    var operationURL = "/artist/" + artistID + "/top";

    if(artistID !== "") {
        DZ.api(operationURL, function(response){
            var track;
            var audioElement;
            document.getElementById("audio").innerHTML = "";

            for(var i = 0; i < response.data.length; i++) {

                track = response.data[i];

                audioElement = document.createElement("audio");
                audioElement.setAttribute("src", track.preview);
                audioElement.setAttribute("controls", "controls");

                document.getElementById("audio").appendChild(audioElement);
            }
        });
    }
}

function retrieveDocument() {

    var documentURL = document.getElementById("documentToRetrieve").value;

    if(documentURL !== "") {
        $.ajax({
            url:  "retrieveDocument",
            type: "GET",
            data: { "documentURL" : documentURL },
            success: function(response) {

                var newParagraph = document.createElement("p");
                newParagraph.innerHTML = response;

                document.getElementById("documents").innerHTML = "";
                document.getElementById("documents").appendChild(newParagraph);

            },
            error: function(xhr) {
                console.log("Error when retrieving document");
            }
        });

    }

}

function insertDocument() {

    var artistID = document.getElementById("artistToRetrieve").value;
    var operationURL = "/artist/" + artistID;

    if(artistID !== "") {
        DZ.api(operationURL, function(response) {
            $.ajax({
                url :  "insertDocument",
                type : "get",
                data : { "document" : response },
                success: function(response) {
                    console.log(response);
                },
                error: function(xhr) {
                    console.log("Error during document insertion");
                }
            });
        });
    }
}

