

var express = require('express');
var app = express();

app.use(express.static(__dirname + "/"));
app.get("/retrieveDocument", retrieveDocument);
app.get("/insertDocument", insertDocument);

app.listen(3000);
console.log("Listening on port 3000");

function insertDocument(request, response) {

    var http = require('http');
    var document = request.query.document;
    var artist = encodeURI(document.name);
    var msg = "";

    var options = {
        host: "localhost",
        port: "5984",
        path: 'http://localhost:5984/deezer/' + artist,
        headers: { 'Content-Type': 'application/json' },
        method: "PUT"
    };

    var req = http.request(options, function(res) {
        res.setEncoding('utf8');
        res.on('data', function (data) {
            msg = data;
            console.log(msg);

        });
    });

    req.write(JSON.stringify(document));
    req.end();

    response.send(msg);

}

function retrieveDocument(request, response) {

    var http = require('http');
    var documentURL = request.query.documentURL;
    var path = "http://localhost:5984/deezer/" + documentURL;

    var req = http.get(path, function(res) {
        res.on('data', function (doc) {
            response.send(doc);
        });
    });

    req.on('error', function(e) {
        response.send("Error" + e.message);
    });

}
